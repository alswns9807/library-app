package com.group.libraryapp.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class UserConfiguration {

//    @Bean
//    public UserRepository userRepository(JdbcTemplate jdbcTemplate) {
//        return new UserRepository(jdbcTemplate);
//    }
}
