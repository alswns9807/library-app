package com.group.libraryapp.dto.calculator.request;

public class CalculatorMultiplyRequest {

    private int number1;
    private int number2;

    public int getNumber1() {
        return number1;
    }

    public int getNumber2() {
        return number2;
    }
}
