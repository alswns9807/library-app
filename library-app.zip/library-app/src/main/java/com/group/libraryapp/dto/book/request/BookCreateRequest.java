package com.group.libraryapp.dto.book.request;

// 3. dto request 생성
public class BookCreateRequest {

    private String name;

    public String getName() {
        return name;
    }
}
